from django.contrib import admin
from cal.models import Event

admin.site.register(Event)
# Register your models here.
